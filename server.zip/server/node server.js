const express = require('express');
const axios = require('axios');
const admin = require('firebase-admin');
const cors = require('cors')
require('dotenv').config();

// Initialize Firebase Admin SDK

const serviceAccount = require('./firebaseServiceAccount.json');
admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    storageBucket: "gs://reelsserve-b3851.appspot.com"
});

const bucket = admin.storage().bucket();

const app = express();
app.use(express.json());
app.use(cors());

app.post('/hklabs/upload-image', async(req, res) => {

    const { imageUrl } = req.body;

    if (!imageUrl) {
        return res.status(400).json({ error: 'Image URL is required' });
    }

    try {
        // Step 1: Download the image
        const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(response.data, 'binary');
        // const ext = path.extname(imageUrl).split('?')[0];
        const ext = 'jpeg'
            // Step 2: Create a unique filename
        const filename = `images/igmixbyhkhub${Date.now()}`;
        console.log(filename);
        // Step 3: Upload the image to Firebase Storage
        const file = bucket.file(filename);
        await file.save(buffer, {
            metadata: { contentType: response.headers['content-type'] },
        });
        // Step 4: Make the file public and get the URL
        await file.makePublic();
        const publicUrl = `https://storage.googleapis.com/${bucket.name}/${filename}`;
        // Return the public URL
        res.status(201).send({ imageurl: publicUrl })

    } catch (error) {
        console.error('Error uploading image:', error);
        res.status(500).json({ error: 'Failed to upload image' });
    }
});

const PORT = process.env.PORT || 3100;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});